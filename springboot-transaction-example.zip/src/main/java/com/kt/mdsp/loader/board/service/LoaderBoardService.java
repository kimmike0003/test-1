package com.kt.mdsp.loader.board.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.kt.mdsp.loader.board.mapper.LoaderBoardMapper;

@Service
public class LoaderBoardService {

	@Autowired
	MydataBoardService mydataBoardService;
	
	@Autowired
	private LoaderBoardMapper loaderBoardMapper;


	@Transactional
	public int insertBoard(Map<String, Object> inputMap)   {
		int rowCount = 0;
			
		rowCount = loaderBoardMapper.insertBoard(inputMap);
		
		return rowCount;
	}

	@Transactional
	public int insertReply(Map<String, Object> inputMap)  {
		int rowCount = 0;
			
		rowCount = loaderBoardMapper.insertReply(inputMap);
		
		return rowCount;
	}
	
}
