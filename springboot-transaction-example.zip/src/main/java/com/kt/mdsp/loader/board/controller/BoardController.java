package com.kt.mdsp.loader.board.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kt.mdsp.loader.board.service.BoardService;
import com.kt.mdsp.loader.board.service.LoaderBoardService; 

@RestController
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@GetMapping("/test")
	public Map<String, Object> insert(@RequestBody String body) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		resultMap = getJsonMap(body);
		boardService.insert(resultMap);
		
		return resultMap;
	}
	
	public Map<String, Object> getJsonMap(String json) throws JsonMappingException, JsonProcessingException {
		Map<String, Object> resultMap = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		resultMap = mapper.readValue(json, Map.class);
		
		return resultMap;
	}
	
}
