package com.kt.mdsp.loader.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

//@Configuration
public class ChainedTransactionConfig {
	/*
		@Bean
		public PlatformTransactionManager transctionManager(
				PlatformTransactionManager loaderTransactionManager
				, PlatformTransactionManager mydataTransactionManager
			) {
			return new ChainedTransactionManager(loaderTransactionManager, mydataTransactionManager);		
		}
		*/
}
