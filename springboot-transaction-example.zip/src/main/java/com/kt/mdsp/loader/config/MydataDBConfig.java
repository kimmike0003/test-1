package com.kt.mdsp.loader.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.kt.mdsp.loader.config.annotation.MydataMapper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@MapperScan(basePackages = "com.kt.mdsp.loader", annotationClass = MydataMapper.class, sqlSessionFactoryRef = "mydataSqlSessionFactory")
@EnableTransactionManagement
public class MydataDBConfig {

	@Value("${spring.datasource.hikari.mydata.driverClassName}")
	private String driverClassName;

	@Value("${spring.datasource.hikari.mydata.jdbcUrl}")
	private String jdbcUrl;

	@Value("${spring.datasource.hikari.mydata.username}")
	private String username;
	
	@Value("${spring.datasource.hikari.mydata.password}")
	private String password;

	@Value("${spring.datasource.hikari.mydata.pool-name}")
	private String poolName;

	@Value("${spring.datasource.hikari.mydata.connectionTimeout}")
	private int connectionTimeout;

	@Value("${spring.datasource.hikari.mydata.validationTimeout}")
	private int validationTimeout;

	@Value("${spring.datasource.hikari.mydata.maximumPoolSize}")
	private int maximumPoolSize;
	
	@Value("${spring.datasource.hikari.mydata.maxLifetime}")
	private int maxLifetime;
	
	@Value("${spring.datasource.hikari.mydata.idle-timeout}")
	private int idleTimeout;
	
	@Value("${spring.datasource.hikari.mydata.autoCommit}")
	private boolean autoCommit;

	@Value("${spring.datasource.hikari.mydata.connectionTestQuery}")
	private String connectionTestQuery;

	
	@Bean(name = "mydataDataSource", destroyMethod = "close")
	public DataSource mydataDataSource() {
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(driverClassName);
		hikariConfig.setJdbcUrl(jdbcUrl);
		hikariConfig.setUsername(username);
		hikariConfig.setPassword(password);
		hikariConfig.setPoolName(poolName);
		hikariConfig.setValidationTimeout(validationTimeout);
		hikariConfig.setConnectionTimeout(connectionTimeout);
		hikariConfig.setMaximumPoolSize(maximumPoolSize);
		hikariConfig.setMaxLifetime(maxLifetime);
		hikariConfig.setConnectionTestQuery(connectionTestQuery);
		hikariConfig.setAutoCommit(autoCommit);
	
		return new HikariDataSource(hikariConfig);
	}

	
	@Bean(name = "mydataSqlSessionFactory")
	public SqlSessionFactory mydataSqlSessionFactory(@Qualifier("mydataDataSource") DataSource mydataDataSource,
			ApplicationContext applicationContext) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(mydataDataSource);
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/*.xml"));
		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "mydataSqlSessionTemplate")
	public SqlSessionTemplate mydataSqlSessionTemplate(SqlSessionFactory mydataSqlSessionFactory) throws Exception {
		return new SqlSessionTemplate(mydataSqlSessionFactory);
	}
	

	 
	@Bean(name = "mydataTransactionManager")
	public PlatformTransactionManager mydataTransactionManager() throws Exception {
		return new DataSourceTransactionManager(mydataDataSource());
	}
	
}