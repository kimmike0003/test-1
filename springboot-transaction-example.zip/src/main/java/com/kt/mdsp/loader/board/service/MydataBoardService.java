package com.kt.mdsp.loader.board.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.kt.mdsp.loader.board.mapper.MydataBoardMapper;

@Service
public class MydataBoardService {

	@Autowired
	private MydataBoardMapper mydataBoardMapper;
	
	public int insertBoard(Map<String, Object> inputMap) {

		int rowCount = 0;
		
		rowCount = mydataBoardMapper.insertBoard(inputMap);
		
		return rowCount;
	}

	public int insertReply(Map<String, Object> inputMap) {

		int rowCount = 0;
		
		rowCount = mydataBoardMapper.insertReply(inputMap);
		
		return rowCount;
	}
}
