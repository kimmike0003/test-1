package com.kt.mdsp.loader.board.mapper;

import java.util.Map;

import com.kt.mdsp.loader.config.annotation.LoaderMapper;

@LoaderMapper
public interface LoaderBoardMapper {

	public int insertBoard(Map<String, Object> map);

	public int insertReply(Map<String, Object> map);

}
