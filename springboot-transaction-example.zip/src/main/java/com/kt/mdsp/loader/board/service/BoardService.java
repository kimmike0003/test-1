package com.kt.mdsp.loader.board.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BoardService {

	@Autowired
	MydataBoardService mydataBoardService;

	@Autowired
	private LoaderBoardService loaderBoardService;

	public int insert(Map<String, Object> inputMap) throws Exception{
		int rowCount = 0;
		try {
			rowCount = mydataBoardService.insertBoard(inputMap);
			System.out.println("mydataBoardService Board:" + rowCount);

			insert2(inputMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rowCount;
	}
	
	public int insert2(Map<String, Object> inputMap)  {
		int rowCount = 0;
	 

			rowCount = loaderBoardService.insertBoard(inputMap);
			System.out.println("loaderBoardService Board:" + rowCount);
			 
			rowCount = loaderBoardService.insertReply(inputMap);
			System.out.println("loaderBoardService Reply:" + rowCount);
			 
		 
		return rowCount;
	}

}
