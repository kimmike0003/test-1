package com.kt.mdsp.loader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTransactionExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTransactionExampleApplication.class, args);
	}

}
