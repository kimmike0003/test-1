package com.kt.mdsp.loader.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.kt.mdsp.loader.config.annotation.LoaderMapper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@MapperScan(basePackages = "com.kt.mdsp.loader", annotationClass = LoaderMapper.class, sqlSessionFactoryRef = "loaderSqlSessionFactory")
@EnableTransactionManagement
public class LoaderDBConfig {

	@Value("${spring.datasource.hikari.loader.driverClassName}")
	private String driverClassName;

	@Value("${spring.datasource.hikari.loader.jdbcUrl}")
	private String jdbcUrl;

	@Value("${spring.datasource.hikari.loader.username}")
	private String username;

	@Value("${spring.datasource.hikari.loader.password}")
	private String password;

	@Value("${spring.datasource.hikari.loader.pool-name}")
	private String poolName;

	@Value("${spring.datasource.hikari.loader.connectionTimeout}")
	private int connectionTimeout;

	@Value("${spring.datasource.hikari.loader.validationTimeout}")
	private int validationTimeout;

	@Value("${spring.datasource.hikari.loader.maximumPoolSize}")
	private int maximumPoolSize;

	@Value("${spring.datasource.hikari.loader.maxLifetime}")
	private int maxLifetime;

	@Value("${spring.datasource.hikari.loader.idle-timeout}")
	private int idleTimeout;

	@Value("${spring.datasource.hikari.loader.autoCommit}")
	private boolean autoCommit;

	@Value("${spring.datasource.hikari.loader.connectionTestQuery}")
	private String connectionTestQuery;


	@Primary
	@Bean(name = "loaderDataSource", destroyMethod = "close")
	public DataSource loaderDataSource() {
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(driverClassName);
		hikariConfig.setJdbcUrl(jdbcUrl);
		hikariConfig.setUsername(username);
		hikariConfig.setPassword(password);
		hikariConfig.setPoolName(poolName);
		hikariConfig.setValidationTimeout(validationTimeout);
		hikariConfig.setConnectionTimeout(connectionTimeout);
		hikariConfig.setMaximumPoolSize(maximumPoolSize);
		hikariConfig.setMaxLifetime(maxLifetime);
		hikariConfig.setConnectionTestQuery(connectionTestQuery);
		hikariConfig.setAutoCommit(autoCommit);

		return new HikariDataSource(hikariConfig);
	}

	@Primary
	@Bean(name = "loaderSqlSessionFactory")
	public SqlSessionFactory loaderSqlSessionFactory(@Qualifier("loaderDataSource") DataSource loaderDataSource,
			ApplicationContext applicationContext) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(loaderDataSource);
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/*.xml"));
		return sqlSessionFactoryBean.getObject();
	}

	@Primary
	@Bean(name = "loaderSqlSessionTemplate")
	public SqlSessionTemplate loaderSqlSessionTemplate(SqlSessionFactory loaderSqlSessionFactory) throws Exception {
		return new SqlSessionTemplate(loaderSqlSessionFactory);
	}

	 
	@Bean(name = "loaderTransactionManager")
	@Primary
	public PlatformTransactionManager loaderTransactionManager() throws Exception {
		return new DataSourceTransactionManager(loaderDataSource());
	}
 
	/*
	
	@Primary
	@Bean(name = "loaderTransactionManager")
	public PlatformTransactionManager loaderTransactionManager(@Qualifier("loaderDataSource") DataSource loaderDataSource) {
	    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(loaderDataSource());
	    transactionManager.setGlobalRollbackOnParticipationFailure(false);
	    return transactionManager;
	}
	*/
}
