package com.kt.mdsp.loader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTransactionExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
